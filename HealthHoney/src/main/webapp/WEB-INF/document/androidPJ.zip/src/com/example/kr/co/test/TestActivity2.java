package com.example.kr.co.test;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class TestActivity2 extends Activity {

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    setContentView(R.layout.activity_test2);
	    WebView webview = (WebView)findViewById(R.id.web2);
	    webview.setWebViewClient(new WebViewClient());
	    WebSettings set = webview.getSettings();
	    set.setJavaScriptEnabled(true);
	    set.setBuiltInZoomControls(true);
	    webview.loadUrl("https://keimc.mooo.com/HealthHoney");
	}

}
