package com.example.kr.co.test;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class TestActivity1 extends Activity {

	@Override
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    setContentView(R.layout.activity_test1);
	    WebView webview = (WebView)findViewById(R.id.web1);
	    webview.setWebViewClient(new WebViewClient());
	    WebSettings set = webview.getSettings();
	    set.setJavaScriptEnabled(true);
	    set.setBuiltInZoomControls(true);
	    //webview.loadUrl("http://keimc.mooo.com:8080/HealthHoney");
	    webview.loadUrl("http://www.naver.com");
	}

}
