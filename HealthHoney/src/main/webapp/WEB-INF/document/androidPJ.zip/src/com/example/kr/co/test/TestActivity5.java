package com.example.kr.co.test;

import android.app.Activity;
import android.os.Bundle;

public class TestActivity5 extends Activity {

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    setContentView(R.layout.activity_test5);
	    // TODO Auto-generated method stub
	}

}
